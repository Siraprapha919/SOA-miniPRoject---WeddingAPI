package com.project.wedding.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Design {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idDesign;
	private String design;


	public Design() {
	}

	public Design(String design) {
		this.design = design;
	}

	
	public Integer getIdDesign() {
		return this.idDesign;
	}

	public void setIdDesign(Integer idDesign) {
		this.idDesign = idDesign;
	}

	public String getDesign() {
		return this.design;
	}

	public void setDesign(String design) {
		this.design = design;
	}

	
}
