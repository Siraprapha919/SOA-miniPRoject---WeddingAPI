package com.project.wedding.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;

import com.project.wedding.entity.Rent;
import com.project.wedding.entity.Type;

@Repository
public interface RentRepository extends CrudRepository<Rent,Integer>{
	
}
