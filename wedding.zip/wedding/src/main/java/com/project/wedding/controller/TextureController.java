package com.project.wedding.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.wedding.entity.Texture;
import com.project.wedding.repository.TextureRepository;


@RestController
public class TextureController {
	@Autowired 
	TextureRepository TextureRepo;
	
	@GetMapping("/textures")
	public List<Texture> getTextureAll() {
		List<Texture> TextureList = (List<Texture>)TextureRepo.findAll();
		return TextureList;
	}
	
	@GetMapping("/textures/{id}")
	public Optional<Texture> getTextureById(@PathVariable(value = "id") Integer id) {
		Optional<Texture> Texture = TextureRepo.findById(id);
		return Texture;
	}
	
	@PostMapping("/textures")
	public Texture createTexture(@RequestBody Texture newTexture) {
	    return TextureRepo.save(newTexture);
	}

	@PutMapping("/textures")
	public Texture updateTexture(@RequestBody Texture newTexture) {
	    return TextureRepo.save(newTexture);
	} 
	
	 @DeleteMapping("/textures/{id}")
	 public void deleteTexture(@PathVariable Integer id) {
	   TextureRepo.deleteById(id);
	 }


}
