package com.project.wedding.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Rent {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id_rent;
	@ManyToOne
	@JoinColumn(name = "id_user")
	private User user;
	private Date date_time_rent;
	private Date date_recieve;
	private Date date_return;
	public Integer getId_rent() {
		return id_rent;
	}
	public void setId_rent(Integer id_rent) {
		this.id_rent = id_rent;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Date getDate_time_rent() {
		return date_time_rent;
	}
	public void setDate_time_rent(Date date_time_rent) {
		this.date_time_rent = date_time_rent;
	}
	public Date getDate_recieve() {
		return date_recieve;
	}
	public void setDate_recieve(Date date_recieve) {
		this.date_recieve = date_recieve;
	}
	public Date getDate_return() {
		return date_return;
	}
	public void setDate_return(Date date_return) {
		this.date_return = date_return;
	}
	
	
}
