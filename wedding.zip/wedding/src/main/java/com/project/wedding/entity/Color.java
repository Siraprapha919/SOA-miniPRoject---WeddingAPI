package com.project.wedding.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Color {
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Integer idColor;
		private String color;
		private String code;
	

		public Color() {
		}

		public Color(String color, String code) {
			this.color = color;
			this.code = code;
		}

	

		public Integer getIdColor() {
			return this.idColor;
		}

		public void setIdColor(Integer idColor) {
			this.idColor = idColor;
		}

		public String getColor() {
			return this.color;
		}

		public void setColor(String color) {
			this.color = color;
		}

		public String getCode() {
			return this.code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		

}
