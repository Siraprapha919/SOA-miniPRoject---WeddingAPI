package com.project.wedding.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.project.wedding.entity.Color;

import org.springframework.data.repository.CrudRepository;

@Repository
public interface ColorRepository extends CrudRepository<Color,Integer>  {

	

}
