package com.project.wedding.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.wedding.entity.Rent;
import com.project.wedding.repository.RentRepository;

@RestController
public class RentController {
	@Autowired 
	RentRepository RentR;
	
	@GetMapping("/rents")
	public List<Rent> getRentAll() {
		List<Rent> RentList = (List<Rent>) RentR.findAll();
		return RentList;
	}
	
	@GetMapping("/rents/{id}")
	public Optional<Rent> getRentById(@PathVariable(value = "id") Integer id) {
		Optional<Rent> rent = RentR.findById(id);
		return rent;
	}
	
	@PostMapping("/rents")
	public Rent createRent(@RequestBody Rent newRent) {
	    return RentR.save(newRent);
	}
	
	
	@PutMapping("/rents")
	public Rent updateRent(@RequestBody Rent newRent) {
	    return RentR.save(newRent);
	} 
	
	 @DeleteMapping("/rents/{id}")
	 public void deleteRent(@PathVariable Integer id) {
	   RentR.deleteById(id);
	 }
	
}
