package com.project.wedding.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Texture {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idTexture;
	private String texture;


	public Texture() {
	}

	public Texture(String texture) {
		this.texture = texture;
	}


	public Integer getIdTexture() {
		return this.idTexture;
	}

	public void setIdTexture(Integer idTexture) {
		this.idTexture = idTexture;
	}

	public String getTexture() {
		return this.texture;
	}

	public void setTexture(String texture) {
		this.texture = texture;
	}

}
