package com.project.wedding.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.wedding.entity.Type;
import com.project.wedding.repository.TypeRepository;


@RestController
public class TypeController {
	@Autowired 
	TypeRepository TypeRepo;
	
	@GetMapping("/types")
	public List<Type> getTypeAll() {
		List<Type> TypeList = (List<Type>)TypeRepo.findAll();
		return TypeList;
	}
	
	@GetMapping("/types/{id}")
	public Optional<Type> getTypeById(@PathVariable(value = "id") Integer id) {
		Optional<Type> Type = TypeRepo.findById(id);
		return Type;
	}
	
	@PostMapping("/types")
	public Type createType(@RequestBody Type newType) {
	    return TypeRepo.save(newType);
	}

	@PutMapping("/types")
	public Type updateType(@RequestBody Type newType) {
	    return TypeRepo.save(newType);
	} 
	
	 @DeleteMapping("/types/{id}")
	 public void deleteType(@PathVariable Integer id) {
	   TypeRepo.deleteById(id);
	 }


}
