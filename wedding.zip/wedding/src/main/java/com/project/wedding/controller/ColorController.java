package com.project.wedding.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.wedding.entity.Color;
import com.project.wedding.repository.ColorRepository;



@RestController
public class ColorController {
	@Autowired 
	ColorRepository colorRepo;
	
	@GetMapping("/colors")
	public List<Color> getColorAll() {
		List<Color> ColorList = (List<Color>)colorRepo.findAll();
		return ColorList;
	}
	
	@GetMapping("/colors/{id}")
	public Optional<Color> getColorById(@PathVariable(value = "id") Integer id) {
		Optional<Color> Color = colorRepo.findById(id);
		return Color;
	}
	
	@PostMapping("/colors")
	public Color createColor(@RequestBody Color newColor) {
	    return colorRepo.save(newColor);
	}

	@PutMapping("/colors")
	public Color updateColor(@RequestBody Color newColor) {
	    return colorRepo.save(newColor);
	} 
	
	 @DeleteMapping("/colors/{id}")
	 public void deleteColor(@PathVariable Integer id) {
	   colorRepo.deleteById(id);
	 }
}
