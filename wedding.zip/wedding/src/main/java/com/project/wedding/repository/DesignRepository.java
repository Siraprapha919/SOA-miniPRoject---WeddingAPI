package com.project.wedding.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.project.wedding.entity.Design;

@Repository
public interface DesignRepository extends CrudRepository<Design,Integer> {

}
