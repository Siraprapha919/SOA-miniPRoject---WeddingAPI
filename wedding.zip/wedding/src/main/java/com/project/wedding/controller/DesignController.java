package com.project.wedding.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.wedding.entity.Design;
import com.project.wedding.repository.DesignRepository;



@RestController
public class DesignController {
	@Autowired 
	DesignRepository DesignRepo;
	
	@GetMapping("/designs")
	public List<Design> getDesignAll() {
		List<Design> DesignList = (List<Design>)DesignRepo.findAll();
		return DesignList;
	}
	
	@GetMapping("/designs/{id}")
	public Optional<Design> getDesignById(@PathVariable(value = "id") Integer id) {
		Optional<Design> Design = DesignRepo.findById(id);
		return Design;
	}
	
	@PostMapping("/designs")
	public Design createDesign(@RequestBody Design newDesign) {
	    return DesignRepo.save(newDesign);
	}

	@PutMapping("/designs")
	public Design updateDesign(@RequestBody Design newDesign) {
	    return DesignRepo.save(newDesign);
	} 
	
	 @DeleteMapping("/designs/{id}")
	 public void deleteDesign(@PathVariable Integer id) {
	   DesignRepo.deleteById(id);
	 }

}
