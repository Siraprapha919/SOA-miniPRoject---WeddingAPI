package com.project.wedding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeddingApplicationTests {

	@Test
	void contextLoads() {
	}

}
